﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// Resource.rc에서 사용되고 있습니다.
//
#define IDB_2                           101
#define IDB_4                           102
#define IDB_8                           103
#define IDB_16                          104
#define IDB_32                          105
#define IDB_64                          106
#define IDB_128                         107
#define IDB_256                         108
#define IDB_512                         109
#define IDB_1024                        110
#define IDB_2048                        111
#define IDB_EMPTY                       112
#define IDR_MENU1                       113
#define ID_MENU_40001                   40001
#define ID_MENU_40002                   40002
#define ID_END                          40003
#define ID_NEW                          40004
#define ID_40005                        40005
#define ID_40006                        40006
#define ID_40007                        40007
#define ID_40008                        40008
#define ID_END_256                      40009
#define ID_END_512                      40010
#define ID_END_1024                     40011
#define ID_END_2048                     40012
#define ID_40013                        40013
#define ID_SAVE                         40014
#define ID_STOP                         40015
#define ID_LOAD                         40016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40017
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
